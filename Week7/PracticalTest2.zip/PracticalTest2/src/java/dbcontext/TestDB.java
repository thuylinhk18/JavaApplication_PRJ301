/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dbcontext;

import model.ProductDAO;

/**
 *
 * @author bebet
 */
public class TestDB {
     public static void main(String[] args) {
         ProductDAO productList = new ProductDAO();
        System.out.println("" + productList.getProducts());
    }
}
